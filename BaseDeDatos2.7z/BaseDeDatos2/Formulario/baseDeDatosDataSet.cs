﻿namespace Formulario {
    
    
    public partial class baseDeDatosDataSet {
        partial class DataTable2DataTable
        {
        }
    
        partial class DataTable1DataTable
        {
        }
    }
}
