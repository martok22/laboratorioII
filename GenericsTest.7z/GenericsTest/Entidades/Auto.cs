﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Auto
    {
        private string _marca;
        private string _patente;
        private ConsoleColor _color;

        public Auto(string marca, string patente, ConsoleColor color)
        {
            this._color = color;
            this._marca = marca;
            this._patente = patente;
        }

    }
}
