﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TV
    {
        private string _marca;
        private int _pulgada;
        private string _resolucion;

        public TV(string marca, int pulgada, string resolucion)
        {
            this._marca = marca;
            this._pulgada = pulgada;
            this._resolucion = resolucion;
        }
    }
}
