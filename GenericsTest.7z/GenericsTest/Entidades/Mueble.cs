﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Mueble
    {
        private string _tamaño;
        private string _material;
        private float _peso;

        public Mueble(string tamaño, string material, float peso)
        {
            this._tamaño = tamaño;
            this._material = material;
            this._peso = peso;
        }

        public override bool Equals(object obj)
        {
            if (obj is Mueble && (Mueble)obj == this) return true;
            return false;
        }

        public static bool operator ==(Mueble mueble1, Mueble mueble2)
        {
            return (mueble1._material == mueble2._material &&
                mueble1._peso == mueble2._peso &&
                mueble1._tamaño == mueble2._tamaño);
        }

        public static bool operator !=(Mueble mueble1, Mueble mueble2)
        {
            return !(mueble1 == mueble2);
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Tamaño: " + this._tamaño);
            sb.AppendLine("Peso: " + this._peso);
            sb.AppendLine("Material: " + this._material);
            return sb.ToString();
        }
    }
}
