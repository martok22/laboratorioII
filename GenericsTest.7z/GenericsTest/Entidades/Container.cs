﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Container<T> : IEnumerable<T>
    {
        private List<T> _elementos;
        private int _cantidadMax;
        

        public Container(int cantidadMax)
        {
            this._cantidadMax = cantidadMax;
            this._elementos = new List<T>();
        }

        private bool EstaLleno()
        {
            return this._elementos.Count == this._cantidadMax;
        }

        private bool EstaElElemento(T elemento) 
        {
            foreach(T item in this._elementos)
            {
                if (item.Equals(elemento))
                    return true;
            }
            return false;
        }

        public bool AgregarElemento(T elemento) 
        {
            this._elementos.Add(elemento);
            return true;
        }

        public static bool operator +(Container<T> deposito, T elemento)
        {
            if (deposito.EstaLleno() || deposito.EstaElElemento(elemento)) return false;
            return deposito.AgregarElemento(elemento);
        }


        public IEnumerator<T> GetEnumerator()
        {
            foreach (T item in this._elementos)
            {
                yield return item;
            }
            // o return this._elements;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}
