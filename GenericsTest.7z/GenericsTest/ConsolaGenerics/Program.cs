﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace ConsolaGenerics
{
    class Program
    {
        static void Main(string[] args)
        {
            Auto miAuto = new Auto("Toyota","555",ConsoleColor.Black);
            Mueble miMueble = new Mueble("40cm","Algarrobo",3);
            TV miTV = new TV("Phillips",35,"1080x1080");
            Persona miPersona = new Persona("Jorge","333");
            Mueble miMueble2 = new Mueble("30cm", "Algarrobo", 4);
            Container<Mueble> miContainer = new Container<Mueble>(5);
            bool dato = miContainer + miMueble;
            dato = miContainer + miMueble2;
            //System.Console.WriteLine(miMueble.ToString());
            foreach (Mueble item in miContainer)
            {
                System.Console.WriteLine(item.ToString());
            }
            System.Console.Read();

        }
    }
}
