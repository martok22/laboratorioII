﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clases;
using Excepciones;
using Interfaces;
using System.Threading;

namespace Formulario
{
    public partial class Form1 : Form
    {
        private Tienda _tienda;

        public Form1()
        {
            InitializeComponent(); 
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // Formulario no carga desde boxes, esta hardcodeado
            try
            {
                this._tienda = new Tienda(1,"Calle Falsa",33);
                this._tienda.Guardar("archivo.BIN");
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnLeer_Click(object sender, EventArgs e)
        {
            try
            {
                this._tienda.Leer(out this._tienda, "archivo.BIN");
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            if (this._tienda!=null)
                MessageBox.Show(this._tienda.ToString());
        }
    }
}
