﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Clases
{
    [Serializable]
    public abstract class Local
    {
        private string _direccion;
        private int _anchoDeFrente;

        public int AnchoDeFrente
        {
            set
            {
                try
                {
                    if (this._anchoDeFrente < 0 || (this._anchoDeFrente % 2) != 0)
                        throw new Exception();
                    else
                        this._anchoDeFrente = value;
                }
                catch(Exception e)
                {
                    throw e;
                }
            }
        }

        /*protected abstract int Legajo
        {
            set { }
            get { return }
        }*/

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Direccion: " + this._direccion);
            sb.Append("Ancho de Frente: " + this._anchoDeFrente + "m.");
            return sb.ToString();
        }

        public Local(string direccion, int ancho)
        {
            this._direccion=direccion;
            this.AnchoDeFrente=ancho;
        }

        public Local() { }

    }
}
