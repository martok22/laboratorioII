﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Interfaces;
using System.IO;
using Excepciones;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace Clases
{
    [Serializable]
    public class Tienda : Local, IArchivo<Tienda>
    {
        private int _legajo;

        protected int Legajo
        {
            get
            {
                return this._legajo;
            }
            set
            {
                this._legajo = value;
            }
        }

        public Tienda(int legajo, string direccion, int ancho) : base(direccion, ancho) 
        {
            this.Legajo = legajo;
        }

        public Tienda() { }

        public string ExponerDatos()
        {
            return this.ToString();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendLine("Legajo: " + this.Legajo);
            return sb.ToString();
        }

        public bool Guardar(string path)
        {
            try
            {
                IFormatter formateador = new BinaryFormatter();
                using (Stream escritor = new FileStream(path,FileMode.Create,FileAccess.Write,FileShare.Write))
                {
                    formateador.Serialize(escritor, this);
                }
                return true;
            }
            catch (NoGuardaException e)
            {
                throw new NoGuardaException("No pudo guardar archivo.",e);
                
            }
            //return false;
            
        }

        public bool Leer(out Tienda datos, string path)
        {
            datos = new Tienda();
            try
            {
                IFormatter formateador = new BinaryFormatter();
                using (Stream lector = new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read))
                {
                    datos = (Tienda)formateador.Deserialize(lector);
                }
                return true;
            }
            catch (NoLeeException e)
            {
                throw new NoLeeException("No pudo leer archivo", e);
            }
        }
    }
}
