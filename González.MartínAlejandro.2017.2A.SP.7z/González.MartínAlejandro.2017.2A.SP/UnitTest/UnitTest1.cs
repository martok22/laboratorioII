﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Clases;
using Excepciones;
using Interfaces;
using System.IO;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ValidaNoGuardaException()
        {
            Tienda t1 = new Tienda(1, "Calle falsa", 45);
            Stream archivo = new FileStream("archivo.BIN", FileMode.Create, FileAccess.Write, FileShare.Write);
            try
            {
                t1.Guardar("Tienda.BIN");
            }
            catch (NoGuardaException e)
            {
                Assert.IsInstanceOfType(e, typeof(NoGuardaException));
                archivo.Close();
            }

        }
        [TestMethod]
        public void ValidaGuardarYLeer()
        {
            Tienda t1 = new Tienda(1, "Calle falsa", 45);
            Tienda t2 = new Tienda();
            bool guardar = false, leer = false;
            try
            {
                guardar = t1.Guardar("archivo.BIN");
            }
            catch (NoGuardaException)
            {
                Assert.Fail();
            }
            finally
            {
                try
                {
                    leer = t1.Leer(out t2, "archivo.BIN");
                }
                catch (NoLeeException)
                {
                    Assert.Fail();
                }
                finally
                {
                    //Assert.AreSame(t1, t2);
                    Assert.IsFalse(!(guardar && leer));
                }
            }
        }
    }
}
