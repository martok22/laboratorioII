﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public interface IArchivo<T>
    {
        bool Guardar(string path);
        bool Leer(out T datos, string path);
    }
}
