﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace conHerencia
{
    class Aula
    {


        private int _numero;
        private string _nombre;
        private List<Persona> ListadoDePersonas;
        private int capacidad;


        public Aula(int numero, string nombre,int capacidad)
        {
            this._nombre = nombre;
            this._numero = numero;
        }
        public int cantidadDePersonas
        {
            get
            {
                return 1;
            }
        }
        public int cantidadDeProfesores
        {
            get
            {
                return 1;
            }
        }
        public bool agregarPersona(Persona unaPersona)
        {
            return true;
        }

        public bool borrarPersona(Persona unaPersona)
        {

            return true;
        }
    }
}
