﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sinHerencia
{
    public class AlumnoEgresado
    {

        private int _dni;
        private string _nombre;
        private string _apellido;
        private string _legajo;
        private DateTime _fechaEgreso;


        public AlumnoEgresado(int dni, string legajo, DateTime fechaEgreso)
        {
            this._dni = dni;
            this._legajo = legajo;

        }

        public void Mostrar()
        {
            throw new System.NotImplementedException();
        }

       
    }
}
