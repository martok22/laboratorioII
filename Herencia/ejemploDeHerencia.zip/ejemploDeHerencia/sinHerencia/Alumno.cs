﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sinHerencia
{
    class Alumno
    {
        private int _dni;
        private string _nombre;
        private string _apellido;

        public string Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }
        private string _legajo;

        public Alumno(int dni , string legajo )
        {
            this._dni = dni;
            this._legajo = legajo;

        }

        public void Mostrar()
        {
            throw new System.NotImplementedException();
        }

    }
}
