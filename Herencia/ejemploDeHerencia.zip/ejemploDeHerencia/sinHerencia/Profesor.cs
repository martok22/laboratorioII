﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sinHerencia
{
    public class Profesor
    {

        private int _dni;
        private string _nombre;
        private string _apellido;
        private string _fichaDocente;
        private int _fechaIngreso;
       


        public Profesor(int dni, string fichaDocente)
        {
            this._dni = dni;
            this._fichaDocente = fichaDocente;

        }
    }
}
