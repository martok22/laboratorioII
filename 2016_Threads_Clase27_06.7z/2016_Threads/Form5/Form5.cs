﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Pelotita_Con_Threads
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            IniciarHilo();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hola");
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            for (int contador = 0; contador < 1000; contador++)
            {
                this.lblNumero.Text = contador.ToString();
            }
        }

        private void Hacer()
        {
            for (int contador = 0; contador < 1000; contador++)
            {
                this.lblNumero.Text = contador.ToString();
            }
        }

        private void IniciarHilo()
        {
            Thread hilo = new Thread(Hacer);
            hilo.Start();
        }

    }
}
