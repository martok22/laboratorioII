﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Pelotita_Con_Threads
{
    public partial class Form5 : Form
    {

        delegate void AsignarNumeroDelegado(string texto);

        public Form5()
        {
            InitializeComponent();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hola");
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            /*for (int contador = 0; contador < 1000; contador++)
            {
                this.lblNumero.Text = contador.ToString();
            }*/
            //Hacer();
            //AsignarNumero("1");
            IniciarHilo();
        }

        private void Hacer()
        {
            for (int contador = 0; contador < 1000000; contador++)
            {
                AsignarNumero(contador.ToString());
            }
        }

        private void IniciarHilo()
        {
            Thread hilo = new Thread(Hacer);
            hilo.Start();
        }

        private void AsignarNumero(string texto)
        {
            // Si se cierra el formulario, y esto 
            try
            {
                // Invoke required devuelve true si los hilos son distintos
                if (this.lblNumero.InvokeRequired)
                {
                    AsignarNumeroDelegado delegado = new AsignarNumeroDelegado(AsignarNumero);
                    this.Invoke(delegado, new object[] { texto });
                }
                else
                {
                    this.lblNumero.Text = texto;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
    }
}
