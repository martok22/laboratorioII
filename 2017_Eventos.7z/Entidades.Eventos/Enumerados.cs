﻿public enum EDificultad
{
    MuyFacil = 20,
    Facil = 10,
    Medio = 5,
    Dificil = 3,
    Nostradamus = 1
}