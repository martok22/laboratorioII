﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ConstructoresPaciente()
        {
            Paciente p = new Paciente("Juan", "Perez");
            Assert.IsTrue(1 == p.Turno);

            Paciente p2 = new Paciente("Juan", "Gimenez", 5);
            Assert.IsTrue(1 == p2.Turno);

            Paciente p3 = new Paciente("Juan", "Gonzalez");
            Assert.IsTrue(1 == p3.Turno);
        }
    }
}
