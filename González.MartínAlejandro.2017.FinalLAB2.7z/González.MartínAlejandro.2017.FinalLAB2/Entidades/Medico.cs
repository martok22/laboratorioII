﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Medico : Persona
    {
        private Paciente pacienteActual;
        protected Random tiempoAleatorio;
        public delegate void FinAtencionPaciente();
        public event FinAtencionPaciente AtencionFinalizada;


        public Paciente AtenderA
        {
            set
            {
                this.pacienteActual = value;
            }
        }

        public virtual string EstaAtendidoA
        {
            get
            {
                return this.pacienteActual.ToString();
            }
        }

        protected abstract void Atender();

        protected void FinalizarAtencion()
        {
            this.AtencionFinalizada();
            this.AtenderA = null;
        }

        private Medico() : base("","")
        {
            this.tiempoAleatorio = new Random();
        }

        public Medico(string nombre, string apellido) : base(nombre, apellido) 
        {
            this.tiempoAleatorio = new Random();
        }


    }
}
