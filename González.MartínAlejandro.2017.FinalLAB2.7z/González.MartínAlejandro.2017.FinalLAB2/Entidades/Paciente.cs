﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Paciente : Persona
    {
        private int turno;
        private static int ultimoTurnoDado;

        static Paciente()
        {
            Paciente.ultimoTurnoDado = 0;
        }

        public int Turno
        {
            get { return this.turno; }
        }

        public Paciente() : base("","") { }

        public Paciente(string nombre, string apellido)
            : base(nombre, apellido)
        {
            this.turno = ++Paciente.ultimoTurnoDado;
        }

        public Paciente(string nombre, string apellido, int turno)
            : this(nombre, apellido)
        {
            Paciente.ultimoTurnoDado = turno;
        }

        public override string ToString()
        {
            StringBuilder bloque = new StringBuilder();
            bloque.AppendFormat("Turno Nº{0}: {2} {1}", this.Turno, this.apellido, this.nombre);
            return bloque.ToString();
        }


    }
}
