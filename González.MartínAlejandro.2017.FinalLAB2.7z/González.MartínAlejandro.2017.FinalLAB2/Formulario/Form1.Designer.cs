﻿namespace Formulario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAtenderMedicoGeneral = new System.Windows.Forms.Button();
            this.btnAtenderMedicoEspecialista = new System.Windows.Forms.Button();
            this.btnSerializarPacientesEnEspera = new System.Windows.Forms.Button();
            this.btnDeserializarPacientesEnEspera = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAtenderMedicoGeneral
            // 
            this.btnAtenderMedicoGeneral.Location = new System.Drawing.Point(15, 23);
            this.btnAtenderMedicoGeneral.Name = "btnAtenderMedicoGeneral";
            this.btnAtenderMedicoGeneral.Size = new System.Drawing.Size(258, 49);
            this.btnAtenderMedicoGeneral.TabIndex = 0;
            this.btnAtenderMedicoGeneral.Text = "Atender Medico General";
            this.btnAtenderMedicoGeneral.UseVisualStyleBackColor = true;
            this.btnAtenderMedicoGeneral.Click += new System.EventHandler(this.btnAtenderMedicoGeneral_Click);
            // 
            // btnAtenderMedicoEspecialista
            // 
            this.btnAtenderMedicoEspecialista.Location = new System.Drawing.Point(15, 87);
            this.btnAtenderMedicoEspecialista.Name = "btnAtenderMedicoEspecialista";
            this.btnAtenderMedicoEspecialista.Size = new System.Drawing.Size(258, 49);
            this.btnAtenderMedicoEspecialista.TabIndex = 1;
            this.btnAtenderMedicoEspecialista.Text = "Atender Medico Especialista";
            this.btnAtenderMedicoEspecialista.UseVisualStyleBackColor = true;
            this.btnAtenderMedicoEspecialista.Click += new System.EventHandler(this.btnAtenderMedicoEspecialista_Click);
            // 
            // btnSerializarPacientesEnEspera
            // 
            this.btnSerializarPacientesEnEspera.Location = new System.Drawing.Point(15, 153);
            this.btnSerializarPacientesEnEspera.Name = "btnSerializarPacientesEnEspera";
            this.btnSerializarPacientesEnEspera.Size = new System.Drawing.Size(258, 49);
            this.btnSerializarPacientesEnEspera.TabIndex = 2;
            this.btnSerializarPacientesEnEspera.Text = "Guardar Pacientes en Espera";
            this.btnSerializarPacientesEnEspera.UseVisualStyleBackColor = true;
            this.btnSerializarPacientesEnEspera.Click += new System.EventHandler(this.btnSerializarPacientesEnEspera_Click);
            // 
            // btnDeserializarPacientesEnEspera
            // 
            this.btnDeserializarPacientesEnEspera.Location = new System.Drawing.Point(15, 212);
            this.btnDeserializarPacientesEnEspera.Name = "btnDeserializarPacientesEnEspera";
            this.btnDeserializarPacientesEnEspera.Size = new System.Drawing.Size(258, 49);
            this.btnDeserializarPacientesEnEspera.TabIndex = 3;
            this.btnDeserializarPacientesEnEspera.Text = "Cargar Pacientes en Espera";
            this.btnDeserializarPacientesEnEspera.UseVisualStyleBackColor = true;
            this.btnDeserializarPacientesEnEspera.Click += new System.EventHandler(this.btnDeserializarPacientesEnEspera_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.btnDeserializarPacientesEnEspera);
            this.Controls.Add(this.btnSerializarPacientesEnEspera);
            this.Controls.Add(this.btnAtenderMedicoEspecialista);
            this.Controls.Add(this.btnAtenderMedicoGeneral);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAtenderMedicoGeneral;
        private System.Windows.Forms.Button btnAtenderMedicoEspecialista;
        private System.Windows.Forms.Button btnSerializarPacientesEnEspera;
        private System.Windows.Forms.Button btnDeserializarPacientesEnEspera;
    }
}

