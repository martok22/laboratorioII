﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Collections;
using System.Threading;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Formulario
{
    public partial class Form1 : Form
    {
        private MEspecialista medicoEspecialista;
        private MGeneral medicoGeneral;
        private Thread mocker;
        private Queue<Paciente> PacientesEnEspera;

        public Form1()
        {
            InitializeComponent();
            this.medicoGeneral = new MGeneral("Luis", "Salinas");
            this.medicoEspecialista = new MEspecialista("Jorge", "Iglesias", MEspecialista.Especialidad.Traumatologo);
            this.PacientesEnEspera = new Queue<Paciente>();
            this.medicoGeneral.AtencionFinalizada += 
            this.medicoEspecialista.AtencionFinalizada +=
        }

        private void btnSerializarPacientesEnEspera_Click(object sender, EventArgs e)
        {
            IFormatter formateador = new BinaryFormatter();
            using (Stream escritor = new FileStream("PacientesEnEspera.txt",FileMode.Append,FileAccess.Write))
            {
                foreach (Paciente p in PacientesEnEspera)
                {
                    formateador.Serialize(escritor, p);
                }
            }
        }

        private void btnDeserializarPacientesEnEspera_Click(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.mocker = new Thread(MockPacientes);
            this.mocker.Start();
        }

        private void MockPacientes()
        {
            this.PacientesEnEspera.Enqueue(new Paciente("Jorge","Algo"));
            Thread.Sleep(5000);
        }

        private void AtenderPacientes(IMedico iMedico)
        {
            if(PacientesEnEspera.Peek() != null)
                iMedico.IniciarAtencion(PacientesEnEspera.Dequeue());
        }

        private void btnAtenderMedicoGeneral_Click(object sender, EventArgs e)
        {
            AtenderPacientes((IMedico)this.medicoGeneral);
        }

        private void btnAtenderMedicoEspecialista_Click(object sender, EventArgs e)
        {
            AtenderPacientes((IMedico)this.medicoEspecialista);
        }

        private void frm_FormClosing()
        {
            if (this.mocker.IsAlive)
                this.mocker.Abort();
        }
    }
}
