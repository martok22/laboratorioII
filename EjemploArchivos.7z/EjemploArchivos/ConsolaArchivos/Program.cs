﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using EntidadesArchivo;
using Entidades;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace ConsolaArchivos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Program.Saludar();
            //AdministradorDeArchivos.Saludar();
            Persona p1 = new Persona("Natalia", "Natalia");
            Persona p2 = new Persona("Jorge", "Jorge");
            Persona p3 = new Persona("Maria", "Maria");
            Aula a1 = new Aula(123,"aulaNombre",true);
            Profesor prof1 = new Profesor();
            Alumno alu1 = new Alumno();
            prof1.Titulo = "Abogado";
            alu1.Legajo = "333";
            a1.ListaDePersonas.Add(p1);
            a1.ListaDePersonas.Add(p2);
            a1.ListaDePersonas.Add(prof1);
            a1.ListaDePersonas.Add(alu1);
            Aula a2 = new Aula(222, "aulaOtroNombre", false);

            try
            {
                /*Program.SerializarPersonaXML(p1);
                System.Console.WriteLine(p2.Dni);
                p2 = Program.DeserializarPersonaXML(p2);
                Program.SerializarPersonaBinaria(p3);
                Program.DeserializarPersonaBinaria(p3);*/
                Program.SerializarAula(a1);
                System.Console.WriteLine(a1.Serializarme());
                a2.Deserializarme();
                
            }
            catch (Exception excp)
            {
                System.Console.WriteLine(excp.Message);
            }
            finally
            {
                System.Console.WriteLine("Nombre p2: {0}", p2._nombre);
                System.Console.WriteLine("Apellido p2: {0}", p2._apellido);
                System.Console.WriteLine("Nombre p3: {0}", p3._nombre);
                System.Console.Read();
            }

        }

        public static void Saludar()
        {
            try
            {
                using (StreamWriter escritor = new StreamWriter("datosProgram.txt"))
                {
                    escritor.Write("Hola");
                }
            }
            catch (Exception excp)
            {
                throw new Exception(excp.Message);
            }
        }

        public static void SerializarPersonaXML(Persona p)
        {
            XmlSerializer Serializador = new XmlSerializer(typeof(Persona));
            StreamWriter escritor = new StreamWriter("Persona.xml");
            Serializador.Serialize(escritor, p);
            escritor.Close();
        }

        public static Persona DeserializarPersonaXML(Persona p)
        {
            XmlSerializer Serializador = new XmlSerializer(typeof(Persona));
            StreamReader reader = new StreamReader("Persona.xml");
            p = (Persona)Serializador.Deserialize(reader);
            reader.Close();
            return p;
        }

        public static void SerializarPersonaBinaria(Persona p)
        {
            //Persona persona = new Persona();
            IFormatter formateador = new BinaryFormatter();
            using (Stream archivo = new FileStream("Persona.bin", FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                formateador.Serialize(archivo, p);
            }
        }

        public static void DeserializarPersonaBinaria(Persona p)
        {
            IFormatter formateador = new BinaryFormatter();
            using (Stream archivo = new FileStream("Persona.bin", FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                //Persona aux;
                p = (Persona)formateador.Deserialize(archivo);
            }
            //return p;
        }

        public static bool SerializarAula(Aula aula)
        {
            try
            {
                XmlSerializer Serializador = new XmlSerializer(typeof(Aula));
                using (StreamWriter escritor = new StreamWriter(aula.Numero+"Aula.xml"))
                {
                    Serializador.Serialize(escritor, aula);
                }
            }
            catch (Exception excp)
            {
                System.Console.WriteLine(excp.Message);
                return false;
            }
            return true;

        }
    }
















/*
        /// <summary>
        /// Functions for performing common Json Serialization operations.
        /// <para>Requires the Newtonsoft.Json assembly (Json.Net package in NuGet Gallery) to be referenced in your project.</para>
        /// <para>Only public properties and variables will be serialized.</para>
        /// <para>Use the [JsonIgnore] attribute to ignore specific public properties or variables.</para>
        /// <para>Object to be serialized must have a parameterless constructor.</para>
        /// </summary>
        
            /// <summary>
            /// Writes the given object instance to a Json file.
            /// <para>Object type must have a parameterless constructor.</para>
            /// <para>Only Public properties and variables will be written to the file. These can be any type though, even other classes.</para>
            /// <para>If there are public properties/variables that you do not want written to the file, decorate them with the [JsonIgnore] attribute.</para>
            /// </summary>
            /// <typeparam name="T">The type of object being written to the file.</typeparam>
            /// <param name="filePath">The file path to write the object instance to.</param>
            /// <param name="objectToWrite">The object instance to write to the file.</param>
            /// <param name="append">If false the file will be overwritten if it already exists. If true the contents will be appended to the file.</param>
            public static void WriteToJsonFile<T>(string filePath, T objectToWrite, bool append = false) where T : new()
            {
                TextWriter writer = null;
                try
                {
                    var contentsToWriteToFile = Newtonsoft.Json.JsonConvert.SerializeObject(objectToWrite);
                    writer = new StreamWriter(filePath, append);
                    writer.Write(contentsToWriteToFile);
                }
                finally
                {
                    if (writer != null)
                        writer.Close();
                }
            }

            /// <summary>
            /// Reads an object instance from an Json file.
            /// <para>Object type must have a parameterless constructor.</para>
            /// </summary>
            /// <typeparam name="T">The type of object to read from the file.</typeparam>
            /// <param name="filePath">The file path to read the object instance from.</param>
            /// <returns>Returns a new instance of the object read from the Json file.</returns>
            public static T ReadFromJsonFile<T>(string filePath) where T : new()
            {
                TextReader reader = null;
                try
                {
                    reader = new StreamReader(filePath);
                    var fileContents = reader.ReadToEnd();
                    return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(fileContents);
                }
                finally
                {
                    if (reader != null)
                        reader.Close();
                }
            }
        }*/
    
}