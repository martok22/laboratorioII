﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{


    public class Humano
    {
        private int _dni;
        public int Dni
        {
            set { this._dni = value; }
            get { return this._dni; }
        }
    }
}
