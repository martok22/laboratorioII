﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    

    public class Aula

    {
        private int _numero;
        private string _nombre;
        private bool _internet;

        public int Numero
        {
            get { return this._numero; }
            set { this._numero = value; }
        }

        public string Nombre
        {
            get { return this._nombre; }      
        }

        public bool Internet
        {
            set { this._internet = value; }
        }
        private List<Persona> _listaDePersonas;

        public List<Persona> ListaDePersonas
        {
            get { return this._listaDePersonas; }
        }

        public Aula()
        {
            this._listaDePersonas = new List<Persona>();
        }

        public Aula(int numero, string nombre, bool internet)
            : this()
        {
            this._internet = internet;
            this._numero = numero;
            this._nombre = nombre;
        }

        /*public static Aula operator +(Aula a, Profesor p)
        {

        }*/

        public bool Serializarme()
        {
            XmlSerializer serializador = new XmlSerializer(this.GetType());
            try
            {
                using (StreamWriter escritor = new StreamWriter("ruta.xml"))
                {
                    serializador.Serialize(escritor, this);
                    return true;
                }
            }
            catch (Exception excp)
            {
                System.Console.Write(excp.Message);
                return false;
            }
        }
        public bool Deserializarme()
        {
            Aula auxiliar;
            XmlSerializer serializador = new XmlSerializer(this.GetType());
            using (StreamReader lector = new StreamReader("ruta.xml"))
            {
                auxiliar = (Aula)serializador.Deserialize(lector);
                return true;
            }
            return false;
        }
           


    }
}
