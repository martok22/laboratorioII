﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    

    public class Profesor : Persona
    {
        private string _titulo;

        public string Titulo
        {
            set { this._titulo = value; }
            get { return this._titulo; }
        }

        public Profesor()
        {
        }

    }
}
