﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
    [Serializable]
    [XmlInclude(typeof(Profesor)),XmlInclude(typeof(Alumno))]
    public class Persona : Humano
    {
        public string _nombre;
        public string _apellido;

        public Persona()
        {
        }

        public Persona(string nombre, string apellido)
        {
            this._nombre = nombre;
            this._apellido = apellido;
        }

        public bool Serializarme()
        {
            XmlSerializer serializador = new XmlSerializer(typeof(Aula));
            try
            {
                using (StreamWriter escritor = new StreamWriter("ruta.xml"))
                {
                    serializador.Serialize(escritor, this);
                    return true;
                }
            }
            catch (Exception excp)
            {
                System.Console.WriteLine(excp.Message);
                return false;
            }
        }

        public Persona Deserializarme()
        {
            Persona p = new Persona();
            XmlSerializer serializador = new XmlSerializer(this.GetType());
            using(StreamReader lector = new StreamReader("ruta.xml"))
            {
                p = (Persona)serializador.Deserialize(lector);
            }
            return p;


        }
    }
}
