﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Objetos
{
    class Tiempo
    {
        public Tiempo(int cantidad)
        {
            this.cantidad = cantidad;
        }

        public int cantidad;

    }
}
